import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Postulante } from '../models/postulante';

@Injectable({
  providedIn: 'root'
})
export class PostulanteService {

  private urlPostulantes = "http://127.0.0.1:8000/api/postulantes/"

  constructor(private http:HttpClient) { }

  getPostulantes(): Observable<any> {
    return this.http.get(this.urlPostulantes);
  }

  createPostulante(postulante:Postulante): Observable<any> {
    return this.http.post(this.urlPostulantes, postulante);
  }

  updatePostulante(id: number, postulante: Postulante): Observable<any> {
    return this.http.put(`${this.urlPostulantes}${id}/`, postulante);
  }

  deletePostulante(id: number): Observable<any> {
    return this.http.delete(`${this.urlPostulantes}${id}/`);
  }
}
