import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Competencia } from '../models/competencia';

@Injectable({
  providedIn: 'root'
})
export class CompetenciaService {

  private urlCompetencias = "http://127.0.0.1:8000/api/competencias/"

  constructor(private http:HttpClient) { }

  getCompetencias():Observable<any> {
    return this.http.get(this.urlCompetencias);
  }

  createCompetencia(competencia:Competencia):Observable<any> {
    return this.http.post(this.urlCompetencias, competencia);
  }

  updateCompetencia(id: number, competencia: Competencia): Observable<any> {
    return this.http.put(`${this.urlCompetencias}${id}/`, competencia);
  }

  deleteCompetencia(id: number): Observable<any> {
    return this.http.delete(`${this.urlCompetencias}${id}/`);
  }
}
