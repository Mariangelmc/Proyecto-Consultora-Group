import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Habilidad } from '../models/habilidad';

@Injectable({
  providedIn: 'root'
})
export class HabilidadService {

  private urlHabilidades = "http://127.0.0.1:8000/api/habilidades/"

  constructor(private http:HttpClient) { }

  getHabilidades():Observable<any> {
    return this.http.get(this.urlHabilidades);
  }

  createHabilidad(habilidad:Habilidad):Observable<any> {
    return this.http.post(this.urlHabilidades, habilidad);
  }

  updateHabilidad(id: number, habilidad: Habilidad): Observable<any> {
    return this.http.put(`${this.urlHabilidades}${id}/`, habilidad);
  }

  deleteHabilidad(id: number): Observable<any> {
    return this.http.delete(`${this.urlHabilidades}${id}/`);
  }
}
