import { Component } from '@angular/core';

@Component({
  selector: 'app-competencias',
  imports: [],
  templateUrl: './competencias.component.html',
  styleUrl: './competencias.component.css'
})
export class CompetenciasComponent {

}
