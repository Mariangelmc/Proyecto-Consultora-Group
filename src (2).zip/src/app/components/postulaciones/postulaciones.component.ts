import { Component } from '@angular/core';

@Component({
  selector: 'app-postulaciones',
  imports: [],
  templateUrl: './postulaciones.component.html',
  styleUrl: './postulaciones.component.css'
})
export class PostulacionesComponent {

}
