import { Component } from '@angular/core';

@Component({
  selector: 'app-cta-banner',
  imports: [],
  templateUrl: './cta-banner.component.html',
  styleUrl: './cta-banner.component.css'
})
export class CtaBannerComponent {

}
