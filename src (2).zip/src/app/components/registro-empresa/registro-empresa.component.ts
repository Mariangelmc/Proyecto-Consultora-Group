import { Component } from '@angular/core';

@Component({
  selector: 'app-registro-empresa',
  imports: [],
  templateUrl: './registro-empresa.component.html',
  styleUrl: './registro-empresa.component.css'
})
export class RegistroEmpresaComponent {

}
