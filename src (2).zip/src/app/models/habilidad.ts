export class Habilidad {
    id!: number;
    nombre!: string;
}
