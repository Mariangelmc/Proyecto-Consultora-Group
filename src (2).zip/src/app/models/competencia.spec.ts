import { Competencia } from './competencia';

describe('Competencia', () => {
  it('should create an instance', () => {
    expect(new Competencia()).toBeTruthy();
  });
});
