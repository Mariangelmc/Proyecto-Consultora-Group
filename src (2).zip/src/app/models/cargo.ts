import { Cliente } from "./cliente";
import { Postulante } from "./postulante";

export class Cargo {
    id!:number;
    nombreCargo!: string;
    mision!: string;
    funcionesResponsabilidades!: string;
    relacionesTrabajo!: string;
    remuneracion!: string;
    horario!: string;
    ubicacion!: string;
    sexo!: string;
    edad!: string;
    nivelInstrucion!: string;
    experienciaLaboral!: string;
    carnetConducir!: boolean;
    areasConocimiento!: string;
    fechaCreacion!: Date;
    fechaActualizacion!: Date;
    cliente!:Cliente;
    postulantes!:Postulante;
}
