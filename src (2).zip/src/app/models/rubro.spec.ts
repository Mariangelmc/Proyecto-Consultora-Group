import { Rubro } from './rubro';

describe('Rubro', () => {
  it('should create an instance', () => {
    expect(new Rubro()).toBeTruthy();
  });
});
