export class Rubro {
    id!:number
    nombre!:string
}
