export class Competencia {
    id!: number;
    capacidadPlanificacionOrganizacion!: string;
    orientacionResultados!: string;
    analisisResolucionProblemas!: string;
    trabajoEquipo!: string;
}
