import { Postulacion } from './postulacion';

describe('Postulacion', () => {
  it('should create an instance', () => {
    expect(new Postulacion()).toBeTruthy();
  });
});
