import { Postulante } from './postulante';

describe('Postulante', () => {
  it('should create an instance', () => {
    expect(new Postulante()).toBeTruthy();
  });
});
