import { Cargo } from './cargo';

describe('Cargo', () => {
  it('should create an instance', () => {
    expect(new Cargo()).toBeTruthy();
  });
});
