export class Postulante {
    id!: number;
    nombre!: string;
    apellido!: string;
    email!: string;
    edad!: number;
    dni!: string;
    cuil!: string;
    telefono!: string;
    nivelEstudio!: string;
    profesionOcupacion!: string;
    localidadResidencia!: string;
    provinciaResidencia!: string;
    disponibilidadCambioResidencia!: string;
    disponibilidadViajar!: string;
    autopercepcion!: string;
    caracteristicasDestacadas!: string;
    fechaCreacion!: Date;
    fechaActualizacion!: Date;
}
