import { Habilidad } from './habilidad';

describe('Habilidad', () => {
  it('should create an instance', () => {
    expect(new Habilidad()).toBeTruthy();
  });
});
