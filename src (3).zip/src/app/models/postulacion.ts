import { Cargo } from "./cargo";
import { Postulante } from "./postulante";

export class Postulacion {
    id!: number;
    cargo!:Cargo;
    postulante!:Postulante;
    curriculumVitae!:File;
    fechaPostulacion!: Date;
    textoExtraido!: string;
    textoNormalizado!: string;
    estado!: string;
    fechaCreacion!: Date;
    fechaActualizacion!: Date;
}
