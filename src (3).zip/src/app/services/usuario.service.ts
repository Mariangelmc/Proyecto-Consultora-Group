import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private urlUsuarios = "http://127.0.0.1:8000/api/usuarios/"

  constructor(private http:HttpClient) { }

  getUsuarios(): Observable<any> {
    return this.http.get(this.urlUsuarios);
  }

  createUsuario(usuario: Usuario): Observable<any> {
    return this.http.post(this.urlUsuarios, usuario);
  }

  updateUsuario(id: number, usuario: Usuario): Observable<any> {
    return this.http.put(`${this.urlUsuarios}${id}/`, usuario);
  }

  deleteUsuario(id: number): Observable<any> {
    return this.http.delete(`${this.urlUsuarios}${id}/`);
  }
}
