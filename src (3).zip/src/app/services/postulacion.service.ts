import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Postulacion } from '../models/postulacion';

@Injectable({
  providedIn: 'root'
})
export class PostulacionService {

  private urlPostulaciones = "http://127.0.1:8000/api/postulaciones/";

  constructor(private http:HttpClient) { }

  getPostulaciones(): Observable<any> {
    return this.http.get(this.urlPostulaciones);
  }

  createPostulacion(postulacion:Postulacion): Observable<any> {
    return this.http.post(this.urlPostulaciones, postulacion);
  }

  updatePostulacion(id: number, postulacion: Postulacion): Observable<any> {
    return this.http.put(`${this.urlPostulaciones}${id}/`, postulacion);
  }

  deletePostulacion(id: number): Observable<any> {
    return this.http.delete(`${this.urlPostulaciones}${id}/`);
  }
}
