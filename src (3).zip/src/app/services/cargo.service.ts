import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cargo } from '../models/cargo';

@Injectable({
  providedIn: 'root'
})
export class CargoService {

  private urlCargos = "http://127.0.0.1:8000/api/cargos/";

  constructor(private http:HttpClient) { }

  getCargos():Observable<any> {
    return this.http.get(this.urlCargos);
  }

  createCargo(cargo:Cargo):Observable<any> {
    return this.http.post(this.urlCargos, cargo);
  }

  updateCargo(id: number, cargo: Cargo): Observable<any> {
    return this.http.put(`${this.urlCargos}${id}/`, cargo);
  }

  deleteCargo(id: number): Observable<any> {
    return this.http.delete(`${this.urlCargos}${id}/`);
  }
}
