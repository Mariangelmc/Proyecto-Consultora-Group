import { Component } from '@angular/core';
import { Cargo } from '../../models/cargo';
import { CargoService } from '../../services/cargo.service';
import { NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cargo',
  imports: [FormsModule],
  templateUrl: './cargo.component.html',
  styleUrl: './cargo.component.css'
})
export class CargoComponent {
  cargo!:Cargo
  listadoCargos:Array<Cargo>
  constructor(private cargoService:CargoService){
    this.listadoCargos=new Array<Cargo>()
  }

  registrarCargos(){
    this.cargoService.createCargo(this.cargo).subscribe({
      next:(resultado)=>{
        console.log("Cargo Registrado")
      },
    error:(error)=>{
        console.error("no se pudo registrar el cargos",error)
      }  
    })
  }

  obtenerCargos(){
    this.cargoService.getCargos().subscribe({
      next:(resultado)=>{
        console.log("listado de cargos:",resultado)
        this.listadoCargos=resultado
      },
      error:(error)=>{
        console.error("no se pudo obtener el listado de cargos",error)
      }
    })
  }


}
