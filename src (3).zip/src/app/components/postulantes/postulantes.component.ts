import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PostulanteService } from '../../services/postulante.service';
import { Postulante } from '../../models/postulante';

@Component({
  selector: 'app-postulantes',
  imports: [FormsModule],
  templateUrl: './postulantes.component.html',
  styleUrl: './postulantes.component.css',
  standalone:true
})
export class PostulantesComponent {

  postulante:Postulante
  provincias:any=[]
  constructor(private postulanteService:PostulanteService){
    this.postulante=new Postulante()
    this.obtenerProvincias()
  }
  registrarPostulante(){
    this.postulanteService.createPostulante(this.postulante).subscribe({
      next:(resultado)=>{
        console.log("Postulante Creado",resultado)
      }
    })
  }
  obtenerProvincias(){
    this.postulanteService.getProvincias().subscribe({
      next:(datos)=>{
        console.log("provincias",datos)
        this.provincias=datos
      }
    })
  }
}
