import { Component } from '@angular/core';

@Component({
  selector: 'app-rubro',
  imports: [],
  templateUrl: './rubro.component.html',
  styleUrl: './rubro.component.css'
})
export class RubroComponent {

}
