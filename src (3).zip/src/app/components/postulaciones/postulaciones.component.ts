import { Component } from '@angular/core';
import { Postulacion } from '../../models/postulacion';
import { PostulacionService } from '../../services/postulacion.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-postulaciones',
  imports: [FormsModule],
  templateUrl: './postulaciones.component.html',
  styleUrl: './postulaciones.component.css'
})
export class PostulacionesComponent {
  postulacion!:Postulacion
  constructor(private postulacionService:PostulacionService){
    this.postulacion=new Postulacion()
  }
  registrarPostulacion(){
    this.postulacionService.createPostulacion(this.postulacion).subscribe({
      next:(resultado)=>{
        console.log("Postulacion Exitosa",resultado)
      },
      error:(error)=>{
        console.error("No se pudo realizar la postulacion",error)
    
      }
    })
  }
}
